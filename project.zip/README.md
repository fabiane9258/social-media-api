# Social Media API

This is a Django REST Framework based social media API project.

## Features (planned)
- User authentication
- Posts (create, update, delete)
- Comments
- Likes
- Follows

## Tech Stack
- Python
- Django
- Django REST Framework
- MySQL / PostgreSQL (to be decided)
>>>>>>> 5a57c3e (Initial project setup with README and .gitignore)
